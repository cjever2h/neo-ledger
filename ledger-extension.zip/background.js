// LEDGER 가계부 보내기 - 서비스 워커
const DEFAULT_APP = 'https://neo-ledger.vercel.app/';

async function getAppUrl() {
  const { appUrl } = await chrome.storage.sync.get('appUrl');
  return appUrl || DEFAULT_APP;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'ledger-text', title: '가계부에 보내기 (선택한 결제 내용)', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'ledger-image', title: '가계부에 영수증으로 보내기', contexts: ['image'] });
  });
});

function waitComplete(tabId) {
  return new Promise(resolve => {
    const done = (id, info) => { if (id === tabId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(done); resolve(); } };
    chrome.tabs.onUpdated.addListener(done);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(done); resolve(); }, 15000);
  });
}

async function sendToApp(payload) {
  const base = await getAppUrl();
  const origin = new URL(base).origin;
  const tabs = await chrome.tabs.query({ url: origin + '/*' });
  let tab = tabs[0];
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    tab = await chrome.tabs.create({ url: base });
    await waitComplete(tab.id);
  }
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: 'MAIN',
    args: [payload],
    func: (p) => {
      const go = () => window.postMessage(Object.assign({ type: 'ledger-ext' }, p), '*');
      if (window.__ledger) { go(); return; }
      let n = 0; const t = setInterval(() => { if (window.__ledger || ++n > 60) { clearInterval(t); go(); } }, 250);
    }
  });
}

// 이미지를 가져와 1800px 이하 JPEG 데이터 URL 로 변환
async function imageToDataUrl(srcUrl) {
  const res = await fetch(srcUrl);
  const blob = await res.blob();
  const bmp = await createImageBitmap(blob);
  const sc = Math.min(1, 1800 / Math.max(bmp.width, bmp.height));
  const c = new OffscreenCanvas(Math.round(bmp.width * sc), Math.round(bmp.height * sc));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.88 });
  const buf = new Uint8Array(await out.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return 'data:image/jpeg;base64,' + btoa(bin);
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    if (info.menuItemId === 'ledger-text' && info.selectionText) {
      await sendToApp({ text: info.selectionText });
    } else if (info.menuItemId === 'ledger-image' && info.srcUrl) {
      // 다른 사이트 이미지는 처음 한 번 해당 사이트 접근 권한이 필요할 수 있음 (사용자 클릭 직후 요청)
      let dataUrl;
      try { dataUrl = await imageToDataUrl(info.srcUrl); }
      catch (e) {
        const origin = new URL(info.srcUrl).origin + '/*';
        const ok = await chrome.permissions.request({ origins: [origin] });
        if (!ok) throw e;
        dataUrl = await imageToDataUrl(info.srcUrl);
      }
      await sendToApp({ image: dataUrl });
    }
  } catch (e) {
    console.error('LEDGER 확장 오류', e);
    chrome.action.setBadgeText({ text: '!' }); chrome.action.setBadgeBackgroundColor({ color: '#ff6b81' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 4000);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.cmd === 'send') { sendToApp(msg.payload).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: String(e) })); return true; }
  if (msg && msg.cmd === 'open') { getAppUrl().then(u => chrome.tabs.create({ url: u })); sendResponse({ ok: true }); }
});
