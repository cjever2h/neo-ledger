const $ = id => document.getElementById(id);
const msg = t => { $('m').textContent = t; };

chrome.storage.sync.get('appUrl').then(({ appUrl }) => { if (appUrl) $('url').value = appUrl; });

$('sel').onclick = async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => String(window.getSelection()) });
    if (r && r.result && r.result.trim()) { $('t').value = r.result.trim(); msg('선택한 글을 가져왔어요'); }
    else msg('이 페이지에서 선택된 글이 없어요');
  } catch (e) { msg('이 페이지에서는 가져올 수 없어요 (직접 붙여넣어 주세요)'); }
};
$('send').onclick = async () => {
  const text = $('t').value.trim();
  if (!text) { msg('보낼 내용을 입력해 주세요'); return; }
  msg('보내는 중...');
  const res = await chrome.runtime.sendMessage({ cmd: 'send', payload: { text } });
  if (res && res.ok) { msg('보냈어요. 가계부 탭에서 확인하세요'); $('t').value = ''; } else msg('보내지 못했어요: ' + ((res && res.error) || ''));
};
$('open').onclick = () => chrome.runtime.sendMessage({ cmd: 'open' });
$('save').onclick = async () => {
  let v = $('url').value.trim();
  if (!v) { await chrome.storage.sync.remove('appUrl'); msg('기본 주소로 되돌렸어요'); return; }
  if (!/^https?:\/\//.test(v)) v = 'https://' + v;
  if (!v.endsWith('/')) v += '/';
  const origin = new URL(v).origin + '/*';
  const ok = await chrome.permissions.request({ origins: [origin] });
  if (!ok) { msg('해당 주소에 대한 접근 권한이 필요해요'); return; }
  await chrome.storage.sync.set({ appUrl: v }); msg('저장했어요');
};
